import random

class Character:
    def __init__(self, name, hp, min_damage, max_damage, crit_chance, defense, attack_type, weakness=None, resistance=None):
        self.name = name
        self.hp = hp
        self.min_damage = min_damage
        self.max_damage = max_damage
        self.crit_chance = crit_chance
        self.defense = defense
        self.attack_type = attack_type
        self.weakness = weakness
        self.resistance = resistance

    def is_alive(self):
        return self.hp > 0

    def attack(self, other):
        base_damage = random.randint(self.min_damage, self.max_damage)
        crit = random.random() < self.crit_chance

        if crit:
            base_damage = int(self.max_damage * 1.5)

        # Elemental adjustment
        if self.attack_type == other.weakness:
            base_damage = int(base_damage * 2)
        elif self.attack_type == other.resistance:
            base_damage = int(base_damage * 0.5)

        # Apply defense
        reduced_damage = base_damage - other.defense

        other.hp -= reduced_damage

        return {
            "attacker": self.name,
            "target": other.name,
            "damage": reduced_damage,
            "critical": crit,
            "attack_type": self.attack_type,
            "target_hp": other.hp
        }
