from character import Character

def simulate_battle(hero_template, monster_template, verbose=True):
    hero = Character(**hero_template)
    monster = Character(**monster_template)

    round_num = 1
    while hero.is_alive() and monster.is_alive():
        if verbose:
            print(f"--- Round {round_num} ---")

        result = hero.attack(monster)
        if verbose:
            print(format_result(result))

        if monster.is_alive():
            result = monster.attack(hero)
            if verbose:
                print(format_result(result))

        round_num += 1

    winner = hero if hero.is_alive() else monster
    if verbose:
        print(f"\n {winner.name} wins!\n")
    return winner.name

def format_result(result):
    hit_type = "CRIT" if result["critical"] else "hit"
    return (
        f"{result['attacker']} {hit_type}s {result['target']} "
        f"with {result['attack_type']} for {result['damage']} damage. "
        f"{result['target']} has {result['target_hp']} HP left."
    )
