from battle import simulate_battle
from heroes import heroes
from monsters import monsters
from collections import defaultdict

def get_hero_by_name(hero_name):    
    hero = next((h for h in heroes if h["name"].lower() == hero_name.lower()), None)
    if hero is None:
        raise ValueError(f"Hero named '{hero_name}' not found.")
    return hero

def run_hero_gauntlet(num_runs=5):
    hero_names = ["Knight", "Pyromancer", "FrostMage", "Rogue", "Warlock",] #Der stod ikke de rigtige navne fra heroes.py filen + vi skal give et nyt variabel navn, da den ellers ville overwrite de "heroes" vi har importet
    hero_name = hero_names[1]
    hero = get_hero_by_name(hero_name)
    
    hero_results = defaultdict(int)  
    hero_monster_results = defaultdict(lambda: defaultdict(int))  

    print(f"\nStarting gauntlet for: {hero_name}")
    
    for run in range(1, num_runs + 1):
        print(f"\n--- Run {run}/{num_runs} ---")
        for monster in monsters:
            print(f"{hero_name} vs {monster['name']}")
            winner = simulate_battle(hero.copy(), monster.copy(), verbose=False)
            if winner == hero_name:
                hero_results[hero_name] += 1
                hero_monster_results[hero_name][monster['name']] += 1
    
    total_battles = len(monsters) * num_runs
    win_rate = hero_results[hero_name] / total_battles * 100
    print(f"{hero_name} won {hero_results[hero_name]}/{total_battles} battles ({win_rate:.2f}%)")
    
    print(f"{hero_name} Win Rates vs Each Monster:")
    for monster in monsters:
        wins = hero_monster_results[hero_name][monster['name']]
        monster_win_rate = (wins / num_runs) * 100 #Nyt variabel navn, da der allerede var en win_rate på linje 32, som så blev overskrevet
        print(f"  {monster['name']}: {wins}/{num_runs} wins ({monster_win_rate:.2f}%)")
    
    print(f"\nFinal Gauntlet Result for {hero_name}:")
    print(f"{hero_name}: {hero_results[hero_name]}/{total_battles} wins ({win_rate:.2f}%)")

if __name__ == "__main__":      
    run_hero_gauntlet(num_runs=5)
